import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import mnist

class CNNLayer:
    def __init__(self,filter_size,padding_type,pooling_type) -> None:
        self.filter_size=filter_size
        self.padding=None
        self.padding_type = padding_type
        self.pooling_type = pooling_type
        
    def window(self):
        self.kernel = np.random.randn(self.filter_size,self.filter_size)
    
train_images = mnist.train_images()
train_labels = mnist.train_labels()

test_images = mnist.test_images()
test_labels = mnist.test_labels()
def window(filter_size):
    kernel = np.random.randn(filter_size,filter_size)/5
    # print(kernel)
    return kernel
def apply_padding(padding_type,image,filter_size):
    if padding_type=='zero' or padding_type=='same':
        # print(image[0])
        image_size = len(image[0])
        padding_size =  image_size- (image_size-filter_size+1)
        padded_image=np.pad(image, [(padding_size, ), (padding_size, )], mode='constant')
        new_size = image_size+padding_size
        # print(padded_image)
        return padded_image, new_size
    elif padding_type=='valid':
        return image
class Convolution:
    def convolve(self,image,kernel,filter_size):
        self.last_kernel=kernel
        self.last_image = image
        self.filter_size = filter_size
        padded_image,image_size = apply_padding('zero',image,filter_size)
        self.last_padded_image = padded_image
        # print(image_size)
        movements = image_size-filter_size+1
        self.movements=movements
        
        row=0
        col=0
        convolved_image=np.zeros((movements,movements))
        # print(convolved_image)
        
        for rows in range(movements):
            for cols in range(movements):
                segment = padded_image[rows:rows+filter_size,cols:cols+filter_size]*kernel
                # print(image)
                total = np.sum(segment)
                # print(segment)
                convolved_image[rows, cols] = total
                # print("-------------------")
                # print(convolved_image)
                # print("----------------")
        return convolved_image
    def backprop(self,gradients,learning_rate):
        padded_gradients,size = apply_padding('zero',gradients,self.filter_size)
        movements=self.movements
        filter_size = self.filter_size
        dl_dkernel=0
        for rows in range(movements):
            for cols in range(movements):
                # print(padded_gradients[rows:rows+filter_size,cols:cols+filter_size].shape)
                # print(self.last_padded_image[rows:rows+filter_size,cols:cols+filter_size].shape)
                dl_dkernel += padded_gradients[rows:rows+filter_size,cols:cols+filter_size]*self.last_padded_image[rows:rows+filter_size,cols:cols+filter_size]
        # updated_kernel = 0
        updated_kernel = self.last_kernel - learning_rate* dl_dkernel        
        return updated_kernel
class Pooling:
    def pooling(self,convolved_image,pool_size):
        self.max_locations=[]
        self.pool_size = pool_size
        self.mean_values=[]
        self.last_convolved_image = convolved_image
        pool_filter = np.ones((pool_size,pool_size))
        if(len(convolved_image[0])%2!=0):
            padded_convolved_image = np.pad(convolved_image, [(0,1 ), (0,1 )], mode='constant',constant_values=(-1e30))
        else:
            padded_convolved_image = convolved_image
        new_size = len(padded_convolved_image[0])
        # print(new_size)
        pooledimage_dim = int(new_size/pool_size)
        # print(pooledimage_dim)
        pooled_image=np.zeros((pooledimage_dim,pooledimage_dim))
        # print(padded_convolved_image)
        for rows in range(0,new_size,2):
            for cols in range(0,new_size,2):
                # print(rows,cols)
                # print(rows,cols)
                segment = padded_convolved_image[rows:rows+pool_size,cols:cols+pool_size]*pool_filter
                # print(image)
                # print(np.amax(segment))
                max_val = np.max(segment)
                location = np.where(convolved_image==np.amax(segment))
                location = list(zip(location[0],location[1]))
                location=location[0]
                self.max_locations.append(location)
                # if(max_val!=0):
                #     print("Location of max value is :",location)
                # print(segment)
                p_row = int(rows/pool_size) 
                p_col = int(cols/pool_size) 
                pooled_image[p_row, p_col] = max_val
                # print("-------------------")
                # print(pooled_image)
                # print("----------------")
        # print(len(self.max_locations))
        return pooled_image
    def avg_pooling(self,convolved_image,pool_size):
        self.max_locations=[]
        self.mean_values=[]
        self.pool_size = pool_size
        self.last_convolved_image = convolved_image
        pool_filter = np.ones((pool_size,pool_size))
        if(len(convolved_image[0])%2!=0):
            padded_convolved_image = np.pad(convolved_image, [(0,1 ), (0,1 )], mode='constant',constant_values=(-1e30))
        else:
            padded_convolved_image = convolved_image
        self.newsize=len(padded_convolved_image[0])
        new_size = self.newsize
        self.last_padded_image = padded_convolved_image
        # print(new_size)
        pooledimage_dim = int(new_size/pool_size)
        # print(pooledimage_dim)
        pooled_image=np.zeros((pooledimage_dim,pooledimage_dim))
        # print(padded_convolved_image)
        for rows in range(0,new_size,2):
            for cols in range(0,new_size,2):
                # print(rows,cols)
                # print(rows,cols)
                segment = padded_convolved_image[rows:rows+pool_size,cols:cols+pool_size]*pool_filter
                # print(image)
                # print(np.amax(segment))
                mean_val = np.mean(segment)
                self.mean_values.append(mean_val)
                p_row = int(rows/pool_size) 
                p_col = int(cols/pool_size) 
                pooled_image[p_row, p_col] = mean_val
                # print("-------------------")
                # print(pooled_image)
                # print("----------------")
        # print(len(self.max_locations))
        return pooled_image
    def create_mask(self,gradients):
       backprop_convolved_image = self.last_convolved_image
       flattened_gradients = gradients.flatten()
    #    print(flattened_gradients)
       for i in range(len(flattened_gradients)):
            location = self.max_locations[i]
            backprop_convolved_image[location[0],location[1]]=flattened_gradients[i]
    #    print(backprop_convolved_image.shape)
       return backprop_convolved_image
    def distribute(self,gradients):
        for rows in range(0,self.newsize,2):
            for cols in range(0,self.newsize,2):
                self.last_padded_image[rows:rows+self.pool_size,cols:cols+self.pool_size] =+ gradients[int(rows/self.pool_size),int(cols/self.pool_size)]
        backprop_convolved_image = self.last_padded_image[0:len(self.last_padded_image[0]),0:len(self.last_padded_image[0])]
        return backprop_convolved_image
    def backprop(self,pool_type,gradients):
        if pool_type=='max':
            self.create_mask(gradients)         
        elif pool_type=='average':
            self.distribute(gradients)         

class ActivatedLayer():
    def __init__(self,input_len,classes) -> None:
        # inputflattenlen = len(input_image.flatten())
        self.weights = np.random.randn(input_len,classes)/7
        self.biases = np.zeros(classes)
        
    def softmax_layer(self,input_image):
        # image_vector = input_image.flatten()
        output = np.dot(self.weights.T,input_image) + self.biases.T 
        exponents = np.exp(output - np.max(output, axis=0, keepdims=True))
        activated_output = exponents/np.sum(exponents) + self.biases
        
        self.prev_exponents = exponents
        self.prev_activated_output = activated_output
        self.prev_output = output
        self.prev_input_image= input_image
        return activated_output

    # this dL_activation_i comes after the entire feed forward has been done 
    # for any given softmax output the derivative of the loss wrt to the ground truth 
    # will only have a non-zero derivative for the ground truth class 
    def backprop(self,dL_dactivation_label):
        for i,v in enumerate(dL_dactivation_label):
            if v!=0: # find derivative of that initial gradient wrt to the weights and bias next
            # this derivative has to be derivated wrt to the softmax function next
            # which has 2 different derivatives depending on whether the class
            # being considered is the ground truth one or not    
                
                # ie derivative of loss wrt to the entire activation output vector
                # print(-np.exp(self.prev_exponents[i]))
                # print(np.exp(self.prev_exponents))
                dactivation_dnonactivated = -np.exp(self.prev_exponents[i]) * np.exp(self.prev_exponents)/np.square(np.sum(self.prev_exponents))
                dactivation_dnonactivated[i] = np.exp(self.prev_exponents[i])*(np.sum(self.prev_exponents)-np.exp(self.prev_exponents[i]))/np.square(np.sum(self.prev_exponents))

# at this stage we have derivatives of the loss wrt to the softmax activation , next we need 
# to go back one more step and get the derivatives wrt to the weights used in the output layer
# the output layer wrt to the derivatives was found are in turn dependent on the weight and bias

                dnonactivation_dw = self.prev_input_image
                dnonactivation_db = 1
                dnonactivation_dinput = self.weights 
# now dL_dW and dL_dB and dL_dinput can be written
                # print(dactivation_dnonactivated.shape,dnonactivation_dw.shape)
                # print(dactivation_dnonactivated[np.newaxis].shape)
                dL_dW = dnonactivation_dw[np.newaxis].T @ ((v*dactivation_dnonactivated)[np.newaxis])  
                dL_dB = (v*dactivation_dnonactivated) * dnonactivation_db
                dL_dinput = dnonactivation_dinput@(v*dactivation_dnonactivated)  
                self.weights = self.weights - 0.00001 * dL_dW
                self.biases  = self.biases  - 0.00001 * dL_dB
                return dL_dinput  # need to reshape this before sending to the pooling layer

# correct = 0
# incorrect=0
# loss=[]
accuracies=[]
kernels=[]
log_losses=[]
for k in range(0,5): # no of kernels
    kernel = window(3)
    kernels.append(kernel)
for epochs in range(0,20):
    correct = 0
    incorrect=0
    log_loss=0
    for i,v in zip(test_images[0:50],test_labels[0:50]):
        i=(i/255) -0.5
        final_volume=[]
    
        # print(final_volume)
        for k in range(len(kernels)): # no of kernels
            kernel = kernels[k]
            convolution =Convolution()
            convolved_image = convolution.convolve(i,kernel,3)

            pool_layer = Pooling()

            pooled_image = pool_layer.avg_pooling(convolved_image,2)
            final_volume.append(pooled_image)
        
        final_volume = np.array(final_volume)
        final_volume_shape = final_volume.shape
        flattened_volume = final_volume.flatten()
        
        length = len(flattened_volume)
        activation_layer = ActivatedLayer(length,10)
        output= activation_layer.softmax_layer(flattened_volume)
        # print(np.sum(output))
        log_loss = -np.log(output[v] + 1e-9)
        if np.argmax(output) == v:
            correct+=1
        else:
            incorrect+=1

        # feed forward ends here
        # backprop starts here
        dL_dactivation_label =np.zeros(10)
        dL_dactivation_label[v]= -1/(output[v] + 1e-9)

        softmax_input_derivative = activation_layer.backprop(dL_dactivation_label)
        pooling_layer_back_input = softmax_input_derivative.reshape(final_volume_shape)
        backprop_convolve_volume=[]
        for i in pooling_layer_back_input:
            backprop =pool_layer.distribute(i)
            backprop_convolve_volume.append(backprop)
        backprop_convolve_volume= np.array(backprop_convolve_volume)

        # print(log_loss)
        # print(backprop_convolve_volume.shape)
        for i in backprop_convolve_volume:
            new_kernel = convolution.backprop(i,-0.00001)
            # print(new_kernel)
            kernels[k] = new_kernel
    print(accuracies)
    log_losses.append(log_loss)
    accuracies.append(correct/(incorrect+correct))
    


    # print(pooling_layer_back_input.shape)
# print(final_volume.shape)
# print(correct)
# print(incorrect)
plt.plot(log_losses)
plt.show()