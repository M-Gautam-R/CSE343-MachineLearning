import numpy as np
import pandas as pd
class dataset:
    def __init__(self,input_points) -> None:
        self.points=input_points
        self.data = pd.DataFrame({'x': [], 'y': [], 'label': []})
    def create(self,noise=False) ->None:
        for _ in range(self.points):
            if(noise==False):
                noise_x= 0
                noise_y = 0
            
            else:
                noise_x= np.random.normal(0,0.1)
                noise_y = np.random.normal(0,0.1)
            label = np.random.choice([0, 1])
            root_sign = np.random.choice([-1, 1])
            # root_sign=1
            x = np.random.uniform(-1, 1)
            if label == 0:
                y = ((1 - x**2)**0.5)*root_sign
            else:
                y = ((1 - x**2)**0.5)*root_sign + 3 
            self.data = pd.concat([self.data, pd.DataFrame({'x': [x+noise_x], 'y': [y+noise_y], 'label': [label]})], ignore_index=True)
            # print(self.data)
    def get(self,add_noise=False):
        if(add_noise==False):
            self.create(noise=False)
            return self.data
        else:
            self.create(noise=True)
            return self.data
    
class PTA:
    # initialise the perceptron trainer
    def __init__(self) -> None:
        pass  
    def train(self,X,y,fixedbias=False):
        def signum(Weights,x,bias):
            # print(np.matmul(Weights,x))
            if(np.matmul(Weights,x)+bias < 0):
                return 0
            else:
                return 1
        self.weights=np.array([0,0]).reshape(1,2)
        self.bias=0
            
        self.train_X=X.to_numpy()
        self.train_Y=y.to_numpy()
        # check =0
        epochs=0
        while(True):
            incorrect=0
            for i in range((self.train_X.shape[0])):
                # print(self.weights.shape)
                # print(self.train_X[i:i+1].shape)
                error = self.train_Y[i] - signum(self.weights,self.train_X[i:i+1].reshape(-1,1),self.bias)
                if(error!=0):
                    # print(self.weights[0])
                    # print(self.weights[0,0],error,self.train_X[i,0])
                    self.weights[0,0] =self.weights[0,0] +error*self.train_X[i,0]
                    self.weights[0,1] =self.weights[0,1] +error*self.train_X[i,1]
                    self.bias = self.bias + error
                    incorrect+=1
                    # print(incorrect,epochs, self.weights, self.bias)
                    # check=1
            epochs+=1
            if(incorrect==0):
                if(fixedbias==True):
                    self.bias=0
                break
            if(epochs==500):
                break
        print("epochs taken were ",epochs)
        print('missclassifieds',incorrect)
        print(self.weights, self.bias)
        return self.weights, self.bias
    def test(self,X,y):
        self.test_X=X
        self.test_Y=y
    
    def plot_decision_boundary():
        pass

        
        
